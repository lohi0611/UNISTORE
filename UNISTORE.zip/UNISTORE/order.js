const abc=document.querySelector('.order-placed');
abc.addEventListener('click',()=>{
    alert("Thank you!");
});