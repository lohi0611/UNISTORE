const cart = [];

function addToCart(name, price) {
  const item = cart.find(p => p.name === name);
  if (item) {
    item.qty++;
  } else {
    cart.push({ name, price, qty: 1 });
  }
  updateCart();
}

function removeFromCart(name) {
  const index = cart.findIndex(p => p.name === name);
  if (index > -1) {
    if (cart[index].qty > 1) {
      cart[index].qty--;
    } else {
      cart.splice(index, 1);
    }
    updateCart();
  }
}

function updateCart() {
  const cartItems = document.getElementById('cart-items');
  const totalPrice = document.getElementById('cart-total');

  if (!cartItems || !totalPrice) return; // Prevent null error

  cartItems.innerHTML = '';
  let total = 0;

  cart.forEach(item => {
    const div = document.createElement('div');
    div.className = 'cart-item';
    div.innerHTML = `
      <span>${item.name} x ${item.qty}</span>
      <span>₹${item.price * item.qty}</span>
      <button onclick="removeFromCart('${item.name}')">-</button>
    `;
    cartItems.appendChild(div);
    total += item.price * item.qty;
  });
  totalPrice.textContent = total;
}

document.addEventListener('DOMContentLoaded', () => {
  const productButtons = document.querySelectorAll('.product-card button');

  productButtons.forEach(button => {
    button.addEventListener('click', () => {
      const card = button.closest('.product-card');
      const name = card.querySelector('h4').textContent;
      const price = parseInt(card.querySelector('p').textContent.replace('₹', ''));
      addToCart(name, price);
    });
  });
});
